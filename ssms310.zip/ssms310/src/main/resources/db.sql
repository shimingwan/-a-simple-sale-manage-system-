create database ssms_db310;
use ssms_db310;
drop table if exists tb_Shaver;
create table tb_Shaver(    
    id int primary key auto_increment,    
    ShaverName varchar(30),    
    ShaverType varchar(30),    
    ShaverPrice double,    
    ShaverNum int,    
    ShaverStatus int
);
insert into tb_Shaver(ShaverName,ShaverType,ShaverPrice,ShaverNum,ShaverStatus)
values('�ɿ�','�Զ�',333.33,12,2),('������','�Զ�',323.98,33,3),('����','�ֶ�',123.32,22,4);
mysql> select * from tb_Shaver;
+----+------------+------------+-------------+-----------+--------------+
| id | ShaverName | ShaverType | ShaverPrice | ShaverNum | ShaverStatus |
+----+------------+------------+-------------+-----------+--------------+
|  1 | �ɿ�       | �Զ�       |      333.33 |        12 |            2 |
|  2 | ������     | �Զ�       |      323.98 |        33 |            3 |
|  3 | ����       | �ֶ�       |      123.32 |        22 |            4 |
+----+------------+------------+-------------+-----------+--------------+
drop table if exists tb_User;
create table tb_User(
    id int primary key auto_increment,
    UserNum varchar(10),
    UserPwd varchar(10)  
);
insert into tb_User(UserNum,UserPwd)
values("jjkkk","123123"),("zzzmm","123456"),("knmmm","112233");
mysql> select * from tb_User;
+----+---------+---------+
| id | UserNum | UserPwd |
+----+---------+---------+
|  1 | jjkkk   | 123123  |
|  2 | zzzmm   | 123456  |
|  3 | knmmm   | 112233  |
+----+---------+---------+