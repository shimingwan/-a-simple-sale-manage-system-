package services;

import java.util.List;

import entity.User310;

public interface IUserServices310 {

	List<User310> selectAll();
	User310 findById(int id);
	void addUser(User310 user);
	void deleteUser(int id);
	void updateUser(User310 user);
	boolean login(String num,String pwd);
}
