package services;

import java.util.List;

import entity.Shaver310;

public interface IShaverServices310 {

	List<Shaver310> selectAll();
	Shaver310 getById(int id);
	void update(Shaver310 b);
	void delete(int id);
	void insert(Shaver310 b);
	int getTotal();
}
