package services.impl;

import java.util.List;

import dao.IUserDao310;
import dao.impl.UserDaoImpl;
import entity.User310;
import services.IUserServices310;

public class UserServicesImpl implements IUserServices310 {

	IUserDao310 iud=new UserDaoImpl();
	@Override
	public List<User310> selectAll() {
		// TODO Auto-generated method stub
		return iud.selectAll();
	}

	@Override
	public User310 findById(int id) {
		// TODO Auto-generated method stub
		return iud.findById(id);
	}

	@Override
	public void addUser(User310 user) {
		// TODO Auto-generated method stub
		iud.addUser(user);
	}

	@Override
	public void deleteUser(int id) {
		// TODO Auto-generated method stub
		iud.deleteUser(id);
	}

	@Override
	public void updateUser(User310 user) {
		// TODO Auto-generated method stub
		iud.updateUser(user);
	}

	@Override
	public boolean login(String num, String pwd) {
		// TODO Auto-generated method stub
		return iud.login(num, pwd);
	}

}
