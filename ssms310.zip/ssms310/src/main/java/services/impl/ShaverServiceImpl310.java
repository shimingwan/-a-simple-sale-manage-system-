package services.impl;

import java.util.List;

import dao.IShaverDao310;
import dao.impl.ShaverDaoImpl310;
import entity.Shaver310;
import services.IShaverServices310;

public class ShaverServiceImpl310 implements IShaverServices310{

	IShaverDao310 sdi=new ShaverDaoImpl310();
	@Override
	public List<Shaver310> selectAll() {
		// TODO Auto-generated method stub
		return sdi.selectAll();
	}

	@Override
	public Shaver310 getById(int id) {
		// TODO Auto-generated method stub
		return sdi.getById(id);
	}

	@Override
	public void update(Shaver310 b) {
		// TODO Auto-generated method stub
		sdi.update(b);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		sdi.delete(id);
	}

	@Override
	public int getTotal() {
		// TODO Auto-generated method stub
		return sdi.getTotal();
	}
	
	@Override
	public void insert(Shaver310 b) {
		sdi.insert(b);
	}

}
