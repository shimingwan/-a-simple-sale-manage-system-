package utils;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.mysql.cj.xdevapi.Statement;

public class DruidUtil {
private static DataSource ds;

	
	static {
		
		try {
			Properties pro=new Properties();
			InputStream in=DruidUtil.class.getClassLoader().getResourceAsStream("druid.properties");
			pro.load(in);
			ds=DruidDataSourceFactory.createDataSource(pro);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static Connection getConn() throws Exception{
		return ds.getConnection();
	}
	public static void main(String[] args) throws Exception {
		Connection con=getConn();
		String sql="select * from tb_Shaver";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		System.out.println("���\tƷ������\t��Ʒ����\t��Ʒ�۸�\t��Ʒ����\t��Ʒ״̬");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)
			+"\t"+rs.getDouble(4)+"\t"+rs.getInt(5)+"\t"+rs.getInt(6));
		}
	}
	public static void close(Connection con,PreparedStatement pstat,Statement stmt,ResultSet rs) {
		close(con);
		close(pstat);
		close(stmt);
		close(rs);
	}
	public static void close(Connection con) {
		try {
			if(con!=null) {
				con.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void close(Statement stat) {
		stat.clearBindings();
	}
	public static void close(PreparedStatement pstmt) {
		try {
			pstmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void close(ResultSet rs) {
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
