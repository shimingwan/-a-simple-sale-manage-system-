package dao;

import java.util.List;

import entity.Shaver310;

public interface IShaverDao310 {

	List<Shaver310> selectAll();
	Shaver310 getById(int id);
	void update(Shaver310 b);
	void insert(Shaver310 b);
	void delete(int id);
	int getTotal();
}
