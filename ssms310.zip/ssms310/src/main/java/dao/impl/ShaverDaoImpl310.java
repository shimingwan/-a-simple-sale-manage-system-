package dao.impl;

import java.util.List;

import dao.BaseDao;
import dao.IShaverDao310;
import entity.Shaver310;

public class ShaverDaoImpl310 extends BaseDao implements IShaverDao310 {

	
	@Override
	public List<Shaver310> selectAll() {
		// TODO Auto-generated method stub
		String sql="select * from tb_Shaver";
		List<Shaver310> list=queryMulti(sql,Shaver310.class,null);
		return list;
	}

	@Override
	public Shaver310 getById(int id) {
		// TODO Auto-generated method stub
		String sql="select * from tb_Shaver where id=?";
		Shaver310 shaver=(Shaver310)querySingle(sql,Shaver310.class,id);
		return shaver;
	}

	@Override
	public void update(Shaver310 b) {
		// TODO Auto-generated method stub
		String sql = "update tb_Shaver set ShaverName=?,ShaverType=?,ShaverPrice=?,ShaverNum=?,ShaverStatus=? where id = ?";
		update(sql,b.getShaverName(),b.getShaverType(),b.getShaverPrice(),b.getShaverNum(),b.getShaverStatus(),b.getId());
	}

	@Override
	public void insert(Shaver310 b) {
		// TODO Auto-generated method stub
		String sql = "insert into tb_Shaver (ShaverName,ShaverType,ShaverPrice,ShaverNum,ShaverStatus) values (?,?,?,?,?)";
		update(sql,b.getShaverName(),b.getShaverType(),b.getShaverPrice(),b.getShaverNum(),b.getShaverStatus());
	}
	

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		String sql = "delete from tb_Shaver where id=?";
		update(sql,id);
	}

	@Override
	public int getTotal() {
		// TODO Auto-generated method stub
		String sql = "select count(id) from tb_Shaver";
		Long total = (Long)queryScalar(sql,null);
		return Integer.parseInt(total.toString());
	}
}
