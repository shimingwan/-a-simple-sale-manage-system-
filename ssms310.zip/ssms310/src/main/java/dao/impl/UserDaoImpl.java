package dao.impl;

import java.util.List;

import dao.BaseDao;
import dao.IUserDao310;
import entity.User310;

public class UserDaoImpl extends BaseDao implements IUserDao310 {

	@Override
	public List<User310> selectAll() {
		// TODO Auto-generated method stub
		String sql="select * from tb_User";
		List<User310> list=queryMulti(sql,User310.class,null);
		return list;
	}

	@Override
	public User310 findById(int id) {
		// TODO Auto-generated method stub
		String sql="select * from tb_User where id=?";
		User310 user=(User310) querySingle(sql,User310.class,id);
		return user;
	}

	@Override
	public void addUser(User310 user) {
		// TODO Auto-generated method stub
		String sql="insert into tb_User(UserNum,UserPwd) values(?,?)";
		update(sql,user.getUserNum(),user.getUserPwd());
	}

	@Override
	public void deleteUser(int id) {
		// TODO Auto-generated method stub
		String sql="delete from tb_User where id=?";
		update(sql,id);
	}

	@Override
	public void updateUser(User310 user) {
		// TODO Auto-generated method stub
		String sql="update tb_User set UserNum=?,UserPwd=? where id=?";
		update(sql,user.getUserNum(),user.getUserPwd(),user.getId());
	}
	
	@Override
	public boolean login(String num,String pwd) {
		String sql="select * from tb_User";
		List<User310> list=queryMulti(sql,User310.class,null);
		for(User310 u:list) {
			if(num.equals(u.getUserNum())) {
				if(pwd.equals(u.getUserPwd())) {
					return true;
				}
			}
		}
		return false;
	}
}
