package entity;

import java.util.Objects;

public class User310 {

	private int id;
	private String UserPwd;
	private String UserNum;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserPwd() {
		return UserPwd;
	}
	public void setUserPwd(String userPwd) {
		UserPwd = userPwd;
	}
	public String getUserNum() {
		return UserNum;
	}
	public void setUserNum(String userNum) {
		UserNum = userNum;
	}
	@Override
	public int hashCode() {
		return Objects.hash(UserNum, UserPwd, id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User310 other = (User310) obj;
		return Objects.equals(UserNum, other.UserNum) && Objects.equals(UserPwd, other.UserPwd)
				&& Objects.equals(id, other.id);
	}
	@Override
	public String toString() {
		return "User310 [id=" + id + ", UserPwd=" + UserPwd + ", UserNum=" + UserNum + "]";
	}
	public User310(Integer id2, String userPwd, String userNum) {
		super();
		this.id = id2;
		UserPwd = userPwd;
		UserNum = userNum;
	}
	public User310() {
		super();
	}
	
}
