package entity;

import java.util.Objects;

public class Shaver310 {

	private int id;
	private String ShaverName;
	private String ShaverType;
	private double ShaverPrice;
	private int ShaverNum;
	private int ShaverStatus;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getShaverName() {
		return ShaverName;
	}
	public void setShaverName(String shaverName) {
		ShaverName = shaverName;
	}
	public String getShaverType() {
		return ShaverType;
	}
	public void setShaverType(String shaverType) {
		ShaverType = shaverType;
	}
	public double getShaverPrice() {
		return ShaverPrice;
	}
	public void setShaverPrice(double shaverPrice) {
		ShaverPrice = shaverPrice;
	}
	public int getShaverNum() {
		return ShaverNum;
	}
	public void setShaverNum(int shaverNum) {
		ShaverNum = shaverNum;
	}
	public int getShaverStatus() {
		return ShaverStatus;
	}
	public void setShaverStatus(int shaverStatus) {
		ShaverStatus = shaverStatus;
	}
	@Override
	public int hashCode() {
		return Objects.hash(ShaverName, ShaverNum, ShaverPrice, ShaverStatus, ShaverType, id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Shaver310 other = (Shaver310) obj;
		return Objects.equals(ShaverName, other.ShaverName) && ShaverNum == other.ShaverNum
				&& Double.doubleToLongBits(ShaverPrice) == Double.doubleToLongBits(other.ShaverPrice)
				&& ShaverStatus == other.ShaverStatus && Objects.equals(ShaverType, other.ShaverType) && id == other.id;
	}
	@Override
	public String toString() {
		return "Shaver310 [id=" + id + ", ShaverName=" + ShaverName + ", ShaverType=" + ShaverType + ", ShaverPrice="
				+ ShaverPrice + ", ShaverNum=" + ShaverNum + ", ShaverStatus=" + ShaverStatus + "]";
	}
	public Shaver310(int id, String shaverName, String shaverType, double shaverPrice, int shaverNum,
			int shaverStatus) {
		super();
		this.id = id;
		ShaverName = shaverName;
		ShaverType = shaverType;
		ShaverPrice = shaverPrice;
		ShaverNum = shaverNum;
		ShaverStatus = shaverStatus;
	}
	public Shaver310() {
		super();
	}
}
