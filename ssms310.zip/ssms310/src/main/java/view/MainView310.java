package view;

import java.util.Scanner;

public class MainView310 {

	static Scanner sc=new Scanner(System.in);
	static ShaverView310 sv=new ShaverView310();
 	static UserView310 uv=new UserView310();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		System.out.println("---------------���뵶���۹���ϵͳ--------------");
		System.out.println("----------------1.�û���¼--------------------");
		System.out.println("----------------0.�˳�------------------------");
		System.out.println("������ָ��: 1 or 0");
		int cmd=sc.nextInt();
		if(0==cmd) {
			System.exit(0);
		}else {
			uv.Login();
		}
	}

}
